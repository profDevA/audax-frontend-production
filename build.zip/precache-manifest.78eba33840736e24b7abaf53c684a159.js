self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "015670fed015d2971418e4478bbb5e36",
    "url": "/index.html"
  },
  {
    "revision": "0bb3cc582274ba335f29",
    "url": "/static/css/2.f51bfa0e.chunk.css"
  },
  {
    "revision": "5b51eb9d317d9409b57e",
    "url": "/static/css/main.44c12581.chunk.css"
  },
  {
    "revision": "0bb3cc582274ba335f29",
    "url": "/static/js/2.19862ba9.chunk.js"
  },
  {
    "revision": "4a8bf8205ac0c91f65436a0bbb044637",
    "url": "/static/js/2.19862ba9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5b51eb9d317d9409b57e",
    "url": "/static/js/main.015ec91d.chunk.js"
  },
  {
    "revision": "16df6bbe1f6ab1cb852bd135be15b9fc",
    "url": "/static/js/main.015ec91d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "11d472d8af8f0e525a36",
    "url": "/static/js/runtime-main.e844ff88.js"
  },
  {
    "revision": "368685db949cddcd901ba54559a727d9",
    "url": "/static/media/angular.368685db.jpg"
  },
  {
    "revision": "692cedc566f9282e7169efb3ca2fefbe",
    "url": "/static/media/argon-react.692cedc5.png"
  },
  {
    "revision": "ab904daa548967670847fc3929bf50f4",
    "url": "/static/media/bootstrap.ab904daa.jpg"
  },
  {
    "revision": "42f9fd6acee87559ac0d6a33488db65e",
    "url": "/static/media/fa-brands-400.42f9fd6a.svg"
  },
  {
    "revision": "659c4d58b00226541ef95c3a76e169c5",
    "url": "/static/media/fa-brands-400.659c4d58.woff2"
  },
  {
    "revision": "8b7a9afd7b95f62e6ee8a72930bfb9ed",
    "url": "/static/media/fa-brands-400.8b7a9afd.woff"
  },
  {
    "revision": "b69de69a4ff8ca0abe96ec0b0c180c5b",
    "url": "/static/media/fa-brands-400.b69de69a.ttf"
  },
  {
    "revision": "ec0716ae8aa1ba781a1a6bcbce833f6c",
    "url": "/static/media/fa-brands-400.ec0716ae.eot"
  },
  {
    "revision": "0b5e3a5451fc62d9023ccafc85bc89db",
    "url": "/static/media/fa-regular-400.0b5e3a54.woff"
  },
  {
    "revision": "0c41971339b9fc5b1cefb0abad1e2e69",
    "url": "/static/media/fa-regular-400.0c419713.svg"
  },
  {
    "revision": "6493321d567eb0f22bd5112fbcf044a8",
    "url": "/static/media/fa-regular-400.6493321d.eot"
  },
  {
    "revision": "b48c48ea8457846a5695b139c377d3d1",
    "url": "/static/media/fa-regular-400.b48c48ea.ttf"
  },
  {
    "revision": "bdadb6ce95c5a2e7b673940721450d3c",
    "url": "/static/media/fa-regular-400.bdadb6ce.woff2"
  },
  {
    "revision": "4478b4d7022cad174e4c04246fe622ef",
    "url": "/static/media/fa-solid-900.4478b4d7.svg"
  },
  {
    "revision": "48f54f63d7711d0912a9a10205538fc4",
    "url": "/static/media/fa-solid-900.48f54f63.ttf"
  },
  {
    "revision": "bcb927a742a8370b76642fd1a9a749c0",
    "url": "/static/media/fa-solid-900.bcb927a7.woff"
  },
  {
    "revision": "f29ad0031ad2c1c14b771ce504e2bfa7",
    "url": "/static/media/fa-solid-900.f29ad003.eot"
  },
  {
    "revision": "fb493903265cad425ccdf8e04fc2de61",
    "url": "/static/media/fa-solid-900.fb493903.woff2"
  },
  {
    "revision": "4ffd4fe7945af123788bf5888296c696",
    "url": "/static/media/github.4ffd4fe7.svg"
  },
  {
    "revision": "87be59a1f7061fc6021876aad6fee028",
    "url": "/static/media/google.87be59a1.svg"
  },
  {
    "revision": "35a52547bfba87e5480f3a5fa7691236",
    "url": "/static/media/img-1-1000x600.35a52547.jpg"
  },
  {
    "revision": "b20ea51ceed6ebc39e5835c1b7ce8782",
    "url": "/static/media/img-1-1000x900.b20ea51c.jpg"
  },
  {
    "revision": "0b8a30b10cbe7708d5f3a4b007c1d665",
    "url": "/static/media/nucleo-icons.0b8a30b1.svg"
  },
  {
    "revision": "2569aaea6eaaf8cd210db7f2fa016743",
    "url": "/static/media/nucleo-icons.2569aaea.woff"
  },
  {
    "revision": "426439788ec5ba772cdf94057f6f4659",
    "url": "/static/media/nucleo-icons.42643978.woff2"
  },
  {
    "revision": "c1733565b32b585676302d4233c39da8",
    "url": "/static/media/nucleo-icons.c1733565.eot"
  },
  {
    "revision": "f82ec6ba2dc4181db2af35c499462840",
    "url": "/static/media/nucleo-icons.f82ec6ba.ttf"
  },
  {
    "revision": "e2582654b8e7b6c285d5017df6427d73",
    "url": "/static/media/profile-cover.e2582654.jpg"
  },
  {
    "revision": "c4eb3d0be0cf5a2d156a123bdf7fb40d",
    "url": "/static/media/react.c4eb3d0b.jpg"
  },
  {
    "revision": "e7c82e5c569db9d9761b13ef1384f702",
    "url": "/static/media/sketch.e7c82e5c.jpg"
  },
  {
    "revision": "53033970a416368da35794389680266f",
    "url": "/static/media/team-1.53033970.jpg"
  },
  {
    "revision": "dcfcf3b77210fe85b0abc8260e6fa70e",
    "url": "/static/media/team-2.dcfcf3b7.jpg"
  },
  {
    "revision": "497bb3590e24c9f8b645864bfffc39b8",
    "url": "/static/media/team-3.497bb359.jpg"
  },
  {
    "revision": "230071328b705f8686cabd26a85ed6a5",
    "url": "/static/media/team-4.23007132.jpg"
  },
  {
    "revision": "53033970a416368da35794389680266f",
    "url": "/static/media/team-5.53033970.jpg"
  },
  {
    "revision": "9378e368a757bd0c7ca556a0258cb527",
    "url": "/static/media/vue.9378e368.jpg"
  }
]);